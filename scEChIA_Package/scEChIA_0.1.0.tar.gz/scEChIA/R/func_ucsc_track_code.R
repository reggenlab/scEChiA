#' @Title Rcode ucsc track file
#'
#' @description Build ucsc track code
#'
#' @param abcnew input file
#'
#'
#' @return abc_col preprocessed input file
#' @export ucsc track input file
#'
#' @examples ucscTrack(abcnew)

#--------------------------------------------------------------------------------------------------------------------
ucscTrack <- function(predInteraction, addscore)
{
  abcnew = predInteraction
  abcnew[,1] = paste("chr",abcnew[,1],sep="")
  abcnew[,4] = paste("chr",abcnew[,4],sep="")
  abc_col = as.data.frame(abcnew[,c(1,2,3,4,5,6)])
  abc_col = setNames(abc_col, c("chrom", "chromStart", "chromEnd", "targetChrom", "targetStart", "targetEnd"))
  abc_col$name = "."
  abc_col$score = ceil(as.numeric(abcnew[,7]) * addscore)
  abc_col$value = "0"
  abc_col$exp = "."
  abc_col$color = "0"
  abc_col$sourceChrom = "."
  abc_col$sourceStart = "."
  abc_col$sourceEnd = "."
  abc_col$sourceName = "."
  abc_col$sourceStrand = "."
  #abc_col$targetChrom = "."
  #abc_col$targetStart = "."
  #abc_col$targetEnd = "."
  abc_col$targetName = "."
  abc_col$targetStrand = "."
  abc_col <- abc_col[c("chrom", "chromStart", "chromEnd","name","score","value","exp","color","chrom","chromStart","chromStart","sourceName","sourceStrand","chrom","chromEnd", "chromEnd", "targetName", "targetStrand")]
  abc_col$chromStart.2 <- as.numeric(as.character( abc_col$chromStart.2 )) + 1
  #abc_col$chromStart.2 = abc_col$chromStart.2 + 1
  abc_col$chromEnd.1 = as.numeric(as.character(abc_col$chromEnd.1)) - 1
  colnames(abc_col)[colnames(abc_col)=="chrom.1"] <- "sourceChrom"
  colnames(abc_col)[colnames(abc_col)=="chromStart.1"] <- "sourceStart"
  colnames(abc_col)[colnames(abc_col)=="chromStart.2"] <- "sourceEnd"
  colnames(abc_col)[colnames(abc_col)=="chrom.2"] <- "targetChrom"
  colnames(abc_col)[colnames(abc_col)=="chromEnd.1"] <- "targetStart"
  colnames(abc_col)[colnames(abc_col)=="chromEnd.2"] <- "targetEnd"
  return(abc_col)
  #write.table(abc_col,file="ucsc_track_file.bed",quote = FALSE,row.names = FALSE,sep="\t")
}


