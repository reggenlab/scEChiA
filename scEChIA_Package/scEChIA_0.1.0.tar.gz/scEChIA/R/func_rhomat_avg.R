#' Title Calculate average rhomatrix
#'
#' @param genomic_region1
#' @param genomic_region2
#' @param gap
#' @param patternf
#' @param data
#' @param chrNo
#' @param startCell
#' @param endCell
#'
#' @return rhomatrix
#' @export avereage rhomatrix
#'
#' @examples rhomatAvg(genomic_region1, genomic_region2, gap,  patternf, data, chrinfo)

rhomatAvg  <- function(genomic_region1, genomic_region2, gap,  patternf, data, chrinfo)
{
  library(varbvs)
  library(pracma)
  mat1 = squaremat_func(genomic_region1, gap, patternf)
  rhomatrix1 = rhomat(mat1, data, chrinfo)
  rhomatrix1 = as.matrix(rhomatrix1)
  mat2 = squaremat_func(genomic_region2, gap, patternf)
  rhomatrix2 = rhomat(mat2, data, chrinfo)
  rhomatrix2 = as.matrix(rhomatrix2)
  rhomat1 = (rhomatrix1+rhomatrix2)/2
  rhomatrix = rhomat1*500
  rhomatrix[is.na(rhomatrix)] <- 0
  return(rhomatrix)
}
