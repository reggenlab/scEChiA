#' @title Predicts High Confidence Chromatin Interaction using Single-Cell ATACseq Data
#'
#' @description This package predicts high confidence chromatin interaction using single-cell ATACseq Data
#'
#' @param chrInfo
#' @param data
#' @param rhomatrix
#' @param chrNo
#' @param startCell
#' @param endCell
#'
#' @return connect21_25kb
#'
#' @export Interaction_Prediction

#--------------------------------------------------------------------------------------------------------------------
mergepeaks1  = function( loci , tagcounts)
{
  lpos = 1
  ind = 0
  tagcounts = as.matrix(tagcounts) ;
  allchr = unique(loci[,1]) ;
  sloci = ceiling(loci[,2] / gap) ;
  fdata = 0 * tagcounts ;
  floci = as.matrix(loci[,1]) ;
  floci1 = matrix(0 , nrow(tagcounts),2) ;
  count = 0 ;
  for (chr in allchr)
  {
    pos = which(loci[,1] == chr) ;
    ldata = as.matrix(tagcounts[pos,]);
    lsloci = as.matrix(sloci[pos] );
    maxloci = max(lsloci) ;
    tdata = matrix( 0, maxloci , ncol(ldata) ) ; 
    
    for (i in 1:length(lsloci))
    {
      tdata[lsloci[i], ] = tdata[lsloci[i], ] + ldata[i, ] ;
    }
    
    tlocs = as.matrix(unique(lsloci)) ;
    lfdata = tdata[tlocs,] ;
    count1 = count + length(tlocs) ;
    print( count );
    print(count1) ;
    print( nrow(lfdata)) ;
    
    fdata[(count +1) : count1, ] = lfdata  ;
    floci[(count +1) : count1, 1] =  chr ;
    floci1[(count +1) : count1 , 1] =  gap*(tlocs-1) ;
    floci1[(count +1) : count1 , 2] =  gap*tlocs  ;
    count = count1 ;
  }
  
  floci = cbind.data.frame(floci[1:count,] , floci1[1:count,]) ;
  ntagcount = fdata[1:count,] ;
  return ( list( nloci= floci , data = ntagcount)) ;
}

################################## Matrix factorization_opRestriction ###############################

opRestriction_intrnl = function(n, idx, x, mode)
{
  m = length(idx)
  
  checkDimensions = function(m,n,x,mode)
  {
    if (mode == 0)
    {
      return
    }
    
    if ((size(x, 1) == 1) && (size(x, 2) == 1))
    {
      if ((m != 1) || (n != 1))
      {
        print('Operator-scalar multiplication not yet supported');
      }
    }
    
    
    if (mode == 1)
    {
      if (size(x, 1) != n)
      {
        print('Incompatible dimensions')
      }
      
      if (size(x, 2) != 1)
      {
        print('Operator-matrix multiplication not yet supported');
      }
    }
    else
    {
      if (size(x, 1) != m)
      {
        print('Incompatible dimensions');
      }
      
      if (size(x, 2) != 1)
      {
        print('Operator-matrix multiplication not yet supported');
      }
    }
  }
  
  if (mode == 0)
  {
    y = c(m, n, c(0,1,0,1), 'Restriction')
  }
  else if (mode == 1)
  {
    y = x[idx]
  }
  else
  {
    y = zeros(n, 1)
    y[idx] = x
  }
  return(y)
}

FunMF = function(mergedData)
{
  processed_new_data1 = t(mergedData$data)
  #processed_new_data1 = mergedData$data
  IDX = which(processed_new_data1 > 0)
  Size = dim(processed_new_data1)
  Len = as.numeric(Size[1] * Size[2])
  n = Len
  idx = IDX
  y = opRestriction_intrnl(n, idx, as.vector(as.matrix(processed_new_data1)), 1)
  sizeX = dim(processed_new_data1)
  
  # Already initialized variables
  err = 1e-6
  x = rand(prod(sizeX), 1)
  outsweep = 10
  insweep = 20
  tol = 1e-4
  decfac = 0.9
  alpha = 1.1
  rankr = 10
  
  Reshape_x = x
  dim(Reshape_x) = c(sizeX)
  SVD = svd(Reshape_x)
  # V = SVD$d[1:4] * t(SVD$v[, 1:4])
  V = SVD$d[1:rankr] * t(SVD$v[, 1:rankr])
  
  for (out in 1:outsweep)
  {
    Temp = y - opRestriction_intrnl(n, idx, x, 1)
    x = x + ((1/alpha) * opRestriction_intrnl(n, idx, Temp, 2))
    dim(x) = c(sizeX)
    X = x
    for (ins in 1:insweep)
    {
      U = mrdivide(X, V)
      for (j in 1:rankr)
      {
        U[, j] = U[, j]/norm(U[, j], type = "2")
      }
      V = mldivide(U, X)
    }
    X = U %*% V
    Index_0 = which(X < 0)
    X[Index_0] = 0
    x = as.vector(as.matrix(X))
  }
  return(X)
}

################################# FunHC-Pred #####################################
funHcPred = function(chrinfo, data, rhomatrix, chrNo, a, b)
{
  nloci = chrinfo
  ntagcount = data
  covariance = cov(ntagcount);
  covariance = cov( t(ntagcount[,a:b]));
  library("glassoFast")
  for (i in (1:nrow(covariance)))
  {
    covariance[i,i] =  covariance[i,i] + 0.0001 ;
  }
  glso = glassoFast(covariance, rho = rhomatrix)
  A = glso$wi ; counter = 0 ;
  B = A ;
  for( i in 1:length(A[1,]) ){
    for(j in 1:length(A[1,]) ) {
      B[i,j] = -A[i,j]/(sqrt(A[i,i] * A[j,j] + 0.00000001)) ;
    }}
  A = B ;
  
  A[is.na(A)] <- 0 ;
  connect = matrix( 1 , nrow(A) * nrow(A) , 7) ;
  for (i in 1:nrow(A)) {
    for (j in i:min(i+50, nrow(A))) {
      
      if( A[i,j] != 0) {
        if (i != j) {
        counter = counter + 1 ;
        connect[counter, 1] = chrNo ; connect[counter, 4] = chrNo ;
        connect[counter, 2] = nloci[i,2] ; connect[counter,3] = nloci[i,2] + gap ;
        connect[counter, 5] = nloci[j,2] ; connect[counter,6] = nloci[j,2] + gap ;
        connect[counter,7] = A[i,j] ;
      }
      
      }}
  }
  
  connect = connect[1:counter,] ;
  
  return(connect)
}

Interaction_Prediction_2 <- function(chrinfo, data, rhoConstant, chrNo, startCell, endCell, chromSize)
{
  mergedData = mergepeaks1(chrinfo,log2(data[,4:ncol(data)]+1))

  #FinalX = FunMF(mergedData)
  #FinalX = t(FinalX)

  chrinfo1 = mergedData$nloci
  rhomatrix = rhoConstant
  #rhomatrix = rhomat1*500
  #rhomatrix[is.na(rhomatrix)] <- 0
  An = funHcPred(chrinfo1, mergedData$data, rhomatrix, chrNo, startCell, endCell)
  An = An[!rowSums(An > chromSize),]
  return(An)
}
