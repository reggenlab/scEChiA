#' @Title Rcode rho matrix
#'
#' @description Build rho matrix
#'
#' @param mat  Matrix file
#' @param data input data
#' @param chrinfo chromosome information
#'
#' @return myrho  final return dataset
#' @export rho Matrix 
#'
#' @examples rhomat(mat, data, chrinfo)

#--------------------------------------------------------------------------------------------------------------------

mergepeaks1  = function( loci , tagcounts )
{
  lpos = 1
  ind = 0
  tagcounts = as.matrix(tagcounts) ;
  allchr = unique(loci[,1]) ;
  sloci = ceiling(loci[,2] / gap) ;
  fdata = 0 * tagcounts ;
  floci = as.matrix(loci[,1]) ;
  floci1 = matrix(0 , nrow(tagcounts),2) ;
  count = 0 ;
  for (chr in allchr)
  {
    pos = which(loci[,1] == chr) ;
    ldata = as.matrix(tagcounts[pos,]);
    lsloci = as.matrix(sloci[pos] );
    maxloci = max(lsloci) ;
    tdata = matrix( 0, maxloci , ncol(ldata) ) ; 
    
    for (i in 1:length(lsloci))
    {
      tdata[lsloci[i], ] = tdata[lsloci[i], ] + ldata[i, ] ;
    }
    
    tlocs = as.matrix(unique(lsloci)) ;
    lfdata = tdata[tlocs,] ;
    count1 = count + length(tlocs) ;
    print( count );
    print(count1) ;
    print( nrow(lfdata)) ;
    
    fdata[(count +1) : count1, ] = lfdata  ;
    floci[(count +1) : count1, 1] =  chr ;
    floci1[(count +1) : count1 , 1] =  gap*(tlocs-1) ;
    floci1[(count +1) : count1 , 2] =  gap*tlocs  ;
    count = count1 ;
  }
  
  floci = cbind.data.frame(floci[1:count,] , floci1[1:count,]) ;
  ntagcount = fdata[1:count,] ;
  return ( list( nloci= floci , data = ntagcount)) ;
}

HicLoci = function(merged){
  nloci=merged$nloci
  HicLoci = matrix(0.1, nrow(nloci) , 1 ) ;
  for (i in 1:nrow(nloci))
  {
    HicLoci[i] = ceiling(0.9 + as.numeric(nloci[i,2]) / gap) ;
  }
  return(HicLoci)
}

myRho = function(HicLoci, merged, mat)
{
  nloci = merged$nloci ;
  myrho = matrix(0.1, nrow(nloci) , nrow(nloci)) ;
  matro = nrow(mat) ;
  pos = which(HicLoci > matro) ;
  HicLoci[pos] = 1 ;
  
  for (i in 1:nrow(nloci)) {
    for (j in i:nrow(nloci)) {
      
      value = mat[HicLoci[i] , HicLoci[j]] ;
      myrho[i,j] =   0.001/(value + 0.1) ;
      myrho[j,i] = myrho[i,j] ;
    }
  }
  myrho = (myrho + t(myrho))/2 ;
  return(myrho)
}

rhomat = function(mat, data, chrinfo)
{
  merged = mergepeaks1(chrinfo,log2(data[,4:ncol(data)]+1))
  HicLoci = HicLoci(merged)
  finalrho = myRho(HicLoci, merged , mat)
  return(finalrho)
}

