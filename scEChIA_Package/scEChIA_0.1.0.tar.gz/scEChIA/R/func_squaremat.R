#' @Title Rcode square matrix
#'
#' @description Build square matrix
#'
#' @param genomic_region1 chromatin interaction matrix
#' @param gap base pair distance
#' @param patternf chromosome number
#'
#' @return mat
#' @export squarematrix
#'
#' @examples cv = squaremat_func(genomic_region1,gap,'patternf')

#------------------------------------------------------------------------------------------
squaremat_func = function(genomic_region1,gap,patternf)
{
  u1 = unique(rbind(genomic_region1[,1], genomic_region1[,2])) ;
  minu1 = min(u1) ;
  maxu1 = max(u1) ;
  masize = (maxu1 - minu1)/gap + 1 ;
  mat = matrix(0, masize, masize) ;
  binloc = matrix(0, masize, 3) ;
  for (i in 1:length(genomic_region1[,1]) )
  {
    idx1 =  floor((genomic_region1[i,1] - minu1)/gap + 1.5) ;
    idx2 =  floor((genomic_region1[i,2] - minu1)/gap + 1.5) ;
    mat[idx1,idx2] = genomic_region1[i,3] ;
    binloc[idx1,1] = patternf ;
    binloc[idx1,2] = genomic_region1[i,1] ;
    binloc[idx1,3] = genomic_region1[i,1] + gap ;
  }
  
  pos = which(binloc[,1] == 0) ;
  for (j in 1:length(pos))
  {
    binloc[pos[j],1]  = patternf ;
    binloc[pos[j],2] = (pos[j] -1) *gap + minu1 ;
    binloc[pos[j],3] = pos[j] *gap + minu1 ;
  }
  mat = round(mat)
  return(mat)
  
}
